# create.py
import pandas as pd
import os
import streamlit as st
from datetime import datetime

USER_DB = "users.csv"
PERFORMANCE_DB = "user_performance.csv"

class data:
    @staticmethod
    def init_dbs():
        """Initialize databases with proper string types"""
        if not os.path.exists(USER_DB):
            pd.DataFrame(columns=["username", "password"]).astype(str).to_csv(USER_DB, index=False)
        if not os.path.exists(PERFORMANCE_DB):
            pd.DataFrame(columns=[
                "username", "date", "category", "difficulty", 
                "correct", "total", "streak"
            ]).astype(str).to_csv(PERFORMANCE_DB, index=False)

    @staticmethod
    def authenticate_user(username, password):
        """Verify credentials with proper string conversion"""
        try:
            data.init_dbs()
            df = pd.read_csv(USER_DB).astype(str)  # Ensure all data is string
            
            # Convert to lowercase and strip whitespace for comparison
            username = str(username).strip().lower()
            password = str(password).strip()
            
            # Find matching user
            match = df[
                (df["username"].str.strip().str.lower() == username) &
                (df["password"].str.strip() == password)
            ]
            
            if match.empty:
                st.error("Invalid username or password")
                return False
            return True
            
        except Exception as e:
            st.error(f"Login error: {str(e)}")
            return False

    @staticmethod
    def create_user(username, password):
        """Create new user with string validation"""
        try:
            data.init_dbs()
            df = pd.read_csv(USER_DB).astype(str)
            
            # Convert to strings and clean inputs
            username = str(username).strip()
            password = str(password).strip()
            
            # Check if username exists (case-insensitive)
            if df["username"].str.strip().str.lower().eq(username.lower()).any():
                st.warning("Username already exists")
                return False
                
            new_user = pd.DataFrame([{
                "username": username,
                "password": password
            }])
            
            pd.concat([df, new_user], ignore_index=True).to_csv(USER_DB, index=False)
            st.success("Account created successfully!")
            return True
            
        except Exception as e:
            st.error(f"Account creation failed: {str(e)}")
            return False

    @staticmethod
    def log_performance(username, category, difficulty, correct, correct_streak,incorrect_streak):
        """Record quiz results"""
        df = pd.read_csv(PERFORMANCE_DB).astype(str)
        if correct_streak== 0:
            streak=-1*incorrect_streak
        if incorrect_streak==0:
            streak=correct_streak
        new_entry = pd.DataFrame([{
            "username": username,
            "date": datetime.now().strftime("%Y-%m-%d %H:%M"),
            "category": category,
            "difficulty": difficulty,
            "correct": int(correct),
            "total": 1,
            "streak": streak
        }])
        pd.concat([df, new_entry], ignore_index=True).to_csv(PERFORMANCE_DB, index=False)

    @staticmethod
    def get_user_stats(username):
        """Get performance metrics"""
        if not os.path.exists(PERFORMANCE_DB):
            return None
        
        # Read CSV without forcing all columns to strings
        df = pd.read_csv(PERFORMANCE_DB)
        
        # Convert specific columns to numeric types
        df["correct"] = pd.to_numeric(df["correct"], errors='coerce').fillna(0)
        df["total"] = pd.to_numeric(df["total"], errors='coerce').fillna(0)
        df["streak"] = pd.to_numeric(df["streak"], errors='coerce').fillna(0)
        
        user_data = df[df["username"] == str(username)]  # Ensure username comparison is string
        
        if user_data.empty:
            return None
            
        total_correct = user_data["correct"].sum()
        total_questions = user_data["total"].sum()
        accuracy = total_correct / total_questions if total_questions > 0 else 0
        
        return {
            "total_questions": int(total_questions),
            "accuracy": accuracy,
            "current_streak": int(user_data.iloc[-1]["streak"]),
            "category_stats": user_data.groupby("category")["correct"].mean().to_dict(),
            "difficulty_stats": user_data.groupby("difficulty")["correct"].mean().to_dict()
        }
    
    
    
    @staticmethod
    def reset_password_page():
        """Simpler password reset without current password verification"""
        st.title("Password Reset")
        
        username = st.text_input("Username")
        new_password = st.text_input("New Password", type="password")
        confirm_password = st.text_input("Confirm New Password", type="password")
        
        if st.button("Reset Password"):
            if new_password != confirm_password:
                st.error("New passwords don't match!")
                return
                
            if data.update_password(username, new_password):
                st.success("Password updated successfully!")
            else:
                st.error("Failed to update password - username not found")

    @staticmethod
    def update_password(username, new_password):
        """Update user password in database"""
        try:
            df = pd.read_csv(USER_DB)
            
            # Convert both to lowercase and strip whitespace for comparison
            username_clean = str(username).strip().lower()
            df["username_clean"] = df["username"].str.strip().str.lower()
            
            # Find user and update password
            mask = df["username_clean"] == username_clean
            if not mask.any():
                return False
                
            # Update password and save
            df.loc[mask, "password"] = str(new_password).strip()
            df = df.drop(columns=["username_clean"])  # Remove temporary column
            df.to_csv(USER_DB, index=False)
            return True
            
        except Exception as e:
            st.error(f"Password update error: {str(e)}")
            return False