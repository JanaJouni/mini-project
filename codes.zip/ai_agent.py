
import random

class AdaptiveQuizAgent:
    def __init__(self, c_streak,i_streak, difficulty):
        self.correct_streak = c_streak
        self.incorrect_streak=i_streak
        self.current_difficulty = difficulty
        

    def sense(self, correct):
        """Receives whether the last answer was correct."""
        return {"correct": correct}

    def think(self, input_data):
        """Updates the internal state (streak and difficulty) based on the answer correctness."""
        if input_data["correct"]:
            self.correct_streak += 1
            self.incorrect_streak = 0
        else:
            self.correct_streak = 0
            self.incorrect_streak += 1

        # Adjust difficulty based on streak
        if self.correct_streak >= 3:
            if self.current_difficulty == "Easy":
                self.current_difficulty = "Medium"
            elif self.current_difficulty == "Medium":
                self.current_difficulty = "Hard"
            self.correct_streak = 0  # reset after level up

        elif self.incorrect_streak >= 3:
            if self.current_difficulty == "Hard":
                self.current_difficulty = "Medium"
            elif self.current_difficulty == "Medium":
                self.current_difficulty = "Easy"
            self.incorrect_streak = 0  # reset after level down

        return {
            "difficulty": self.current_difficulty,
            "correct_streak": self.correct_streak,
            "incorrect_streak": self.incorrect_streak
        }

    def act(self, action, questions_df):
        """Selects a question of the appropriate difficulty."""
        available = questions_df[questions_df["difficulty"] == action["difficulty"]]
        if available.empty:
            return questions_df.sample(1).iloc[0]  # fallback
        return available.sample(1).iloc[0]

    def learn(self, experience):
        """Optional learning hook – currently logs experience."""
        print(f"Learning from experience: {experience}")

    def select_question_index(self, questions_df):
        """Returns a random index from the DataFrame (used to fetch the next question)."""
        if questions_df.empty:
            return None
        return random.choice(questions_df.index.tolist())