import pandas as pd

def load_questions():
    # Load from CSV or DB
    df = pd.read_csv("train_with_difficulty.csv")
    # Convert 'options' string to list if stored as stringified list
    df["options"] = df["options"].apply(eval)  # careful with eval, only if you trust the data
    return df
