import streamlit as st
import pandas as pd
import ast
import re
from create import data
from ai_agent import AdaptiveQuizAgent
from api_handler import AIExplainer 
from datetime import datetime

explainer = AIExplainer()

# --- Session Initialization ---
if "logged_in" not in st.session_state:
    st.session_state.logged_in = False
if "page" not in st.session_state:
    st.session_state.page = "login"
if "answered" not in st.session_state:
    st.session_state.answered = False
if "user_answer" not in st.session_state:
    st.session_state.user_answer = None
if "current_question" not in st.session_state:
    st.session_state.current_question = None
if "category" not in st.session_state:
    st.session_state.category = None
if "category_confirmed" not in st.session_state:
    st.session_state.category_confirmed = False
if "ai_explanation" not in st.session_state:
    st.session_state.ai_explanation = ""
if "correct" not in st.session_state:
    st.session_state.correct = False
if "show_dashboard" not in st.session_state:
    st.session_state.show_dashboard = True

# --- Utility Functions ---
def prettify_formula(expr):
    if not expr or expr == 'N/A':
        return "N/A"
    expr = re.sub(r'const_(\d+)', r'\1', expr)
    expr = expr.replace('*', '×').replace('/', '÷')
    expr = re.sub(r'([+\-×÷])', r' \1 ', expr)
    expr = re.sub(r'\s+', ' ', expr).strip()
    return expr

def prettify_rationale(text):
    if not text or text == 'N/A':
        return "N/A"
    return text.replace(',', ',\n').replace('.', '.\n')

def prettify_linear_steps(linear_raw):
    if not linear_raw or linear_raw == 'N/A':
        return ["N/A"]
    steps = linear_raw.strip('|').split('|')
    pretty_steps = []
    for i, step in enumerate(steps, 1):
        step = step.replace('n0', 'n')
        step = re.sub(r'const_(\d+)', r'\1', step)
        step = re.sub(r'#(\d+)', r'result #\1', step)
        pretty_steps.append(f"{i}. {step}")
    return pretty_steps

# --- Login Page ---
def login_page():
    st.title("📚 Adaptive Quiz System")
    st.subheader("Login or Register")
    username = st.text_input("Username", key="login_username")
    password = st.text_input("Password", type="password", key="login_password")

    col1, col2 = st.columns(2)
    with col1:
        if st.button("Login"):
            if username and password:
                if data.authenticate_user(username.strip(), password.strip()):
                    st.session_state["username"] = username
                    st.session_state["logged_in"] = True
                    st.success("✅ Logged in!")
                    st.rerun()
                else:
                    st.error("❌ Invalid username or password.")
            else:
                st.warning("Please enter both username and password.")

    with col2:
        if st.button("Create Account"):
            if username and password:
                created = data.create_user(username.strip(), password.strip())
                if created:
                    st.session_state["username"] = username
                    st.session_state["logged_in"] = True
                    st.success("✅ Account created and logged in!")
                    st.rerun()
                else:
                    st.warning("⚠️ Username already exists.")
            else:
                st.warning("Please enter both username and password.")

    if st.button("Forgot Password?"):
        st.session_state.page = "reset"
        st.rerun()

# --- Performance Dashboard ---
def performance_dashboard():
    st.title("📊 Your Learning Dashboard")
    
    stats = data.get_user_stats(st.session_state["username"])
    if not stats:
        st.info("No performance data yet. Complete some quizzes first!")
        if st.button("Start Quiz"):
            st.session_state.show_dashboard = False
            st.rerun()
        return
    
    st.subheader("Overall Performance")
    col1, col2, col3 = st.columns(3)
    with col1:
        st.metric("Total Questions", stats["total_questions"])
    with col2:
        st.metric("Accuracy", f"{stats['accuracy']:.0%}")
    with col3:
        st.metric("Current Streak", stats["current_streak"])
    
    st.divider()
    
    st.subheader("By Category")
    tabs = st.tabs(list(stats["category_stats"].keys()))
    for tab, (category, accuracy) in zip(tabs, stats["category_stats"].items()):
        with tab:
            st.metric(f"{category} Accuracy", f"{accuracy:.0%}")
            st.progress(accuracy)
    
    st.subheader("By Difficulty Level")
    for difficulty, accuracy in stats["difficulty_stats"].items():
        col1, col2 = st.columns([1, 4])
        with col1:
            st.write(f"{difficulty}:")
        with col2:
            st.progress(accuracy, text=f"{accuracy:.0%}")
    
    st.divider()
    
    if st.button("Start New Quiz", type="primary"):
        st.session_state.show_dashboard = False
        st.rerun()

# --- Quiz Page ---
def quiz_page():
    st.title("🧠 Adaptive Quiz System")

    # Initialize agent
    if "agent" not in st.session_state:
        st.session_state.agent = AdaptiveQuizAgent(c_streak=0,i_streak=0, difficulty="Easy")

    # Load questions
    try:
        questions_df = pd.read_csv("train_with_difficulty.csv").astype(str)
        questions_df = questions_df[
            (~questions_df['category'].isin(['', 'value'])) &
            (~questions_df['difficulty'].isin(['', 'Value']))
        ]
    except Exception as e:
        st.error(f"Data loading failed: {e}")
        return

    # Category selection
    if not st.session_state.category_confirmed:
        available_categories = sorted([c for c in questions_df['category'].unique() if c])
        category_display = st.selectbox(
            "Select a category:",
            [c.capitalize() for c in available_categories],
            index=None,
            placeholder="Choose a category"
        )
        if st.button("Proceed to Quiz"):
            if category_display:
                st.session_state.category = category_display.lower()
                st.session_state.category_confirmed = True
                st.rerun()
            else:
                st.warning("Please select a category to continue.")
        st.stop()

    # Load question with fallback
    if st.session_state.current_question is None:
        matched = questions_df[
            (questions_df['category'] == st.session_state.category) & 
            (questions_df['difficulty'] == st.session_state.agent.current_difficulty)
        ]
        if len(matched) == 0:
            matched = questions_df  # Fallback to all questions
        
        try:
            st.session_state.current_question = matched.sample(1).iloc[0].to_dict()
        except:
            st.error("No questions available. Please check your data file.")
            st.stop()

    question = st.session_state.current_question

    # Display question
    st.markdown(f"### Difficulty: {question['difficulty']} | Category: {question['category'].capitalize()}")
    st.write(f"**Q:** {question['Problem']}")

    # Display options
    try:
        options = ast.literal_eval(question["options"]) if isinstance(question["options"], str) else question["options"]
    except:
        options = [opt.strip() for opt in question["options"].split(",")]

    # Answer submission
    if not st.session_state.answered:
        st.session_state.user_answer = st.radio("Choose one:", options, key="answer_radio")
        if st.button("Submit Answer"):
            st.session_state.answered = True
            try:
                user_letter = re.match(r'^([a-zA-Z])[\)\.]?', str(st.session_state.user_answer)).group(1).upper()
                correct_letter = re.match(r'^([a-zA-Z])[\)\.]?', str(question["correct"])).group(1).upper()
                st.session_state.correct = user_letter == correct_letter
            except:
                st.session_state.correct = False

            # Update agent and log performance
            st.session_state.agent.think({"correct": st.session_state.correct})
            data.log_performance(
                username=st.session_state["username"],
                category=st.session_state.category,
                difficulty=st.session_state.agent.current_difficulty,
                correct=st.session_state.correct,
                correct_streak=st.session_state.agent.correct_streak,
                incorrect_streak=st.session_state.agent.incorrect_streak
            )

            if st.session_state.correct:
                st.success("✅ Correct!")
            else:
                st.error(f"❌ Incorrect! Correct answer is: {question['correct']}")

            # Show explanation
            with st.expander("📘 Explanation and Formula", expanded=True):
                rationale = prettify_rationale(question.get('Rationale', 'N/A'))
                annotated = prettify_formula(question.get('annotated_formula', 'N/A'))
                linear_steps = prettify_linear_steps(question.get('linear_formula', 'N/A'))
                
                st.markdown(f"**Rationale:**\n{rationale}")
                st.markdown(f"**Annotated Formula:** `{annotated}`")
                st.markdown("**Linear Steps:**")
                for step in linear_steps:
                    st.markdown(f"- `{step}`")
    else:
        try:
            index = options.index(st.session_state.user_answer)
        except ValueError:
            index = 0
        st.radio("Choose one:", options, index=index, disabled=True)

    # Bottom buttons
    col1, col2 = st.columns(2)
    with col1:
        if st.button("Next Question"):
            st.session_state.answered = False
            st.session_state.user_answer = None
            st.session_state.ai_explanation = ""
            st.session_state.current_question = None
            st.rerun()
    with col2:
        if st.session_state.answered and not st.session_state.correct:
            if st.button("🤔 Didn't understand why?"):
                with st.spinner("Generating AI explanation..."):
                    try:
                        response = explainer.generate_explanation(
                            problem=question["Problem"],
                            user_answer=st.session_state.user_answer,
                            correct_answer=question["correct"]
                        )
                        st.session_state.ai_explanation = response
                    except Exception as e:
                        st.session_state.ai_explanation = f"⚠️ Error: {str(e)}"

    # Display AI explanation
    if st.session_state.get("ai_explanation"):
        st.markdown("### 🧠 AI Explanation")
        st.text_area("Explanation", st.session_state.ai_explanation, height=300)

# --- Routing ---
if st.session_state.page == "reset":
    data.reset_password_page()
    if st.button("Back to Login"):
        st.session_state.page = "login"
        st.rerun()
elif st.session_state.logged_in:
    if st.session_state.get("show_dashboard", True):
        performance_dashboard()
    else:
        quiz_page()
else:
    login_page()