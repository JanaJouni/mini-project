import os
from dotenv import load_dotenv
import requests

load_dotenv()

class AIExplainer:
    def __init__(self):
        self.api_key = os.getenv("OPENROUTER_API_KEY")
        self.base_url = "https://openrouter.ai/api/v1"
    
    def generate_explanation(self, problem: str, user_answer: str, correct_answer: str) -> str:
        if not self.api_key:
            return "🔑 Error: API key not configured in .env file"

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json",
            "HTTP-Referer": "http://localhost",
            "X-Title": "adaptive-quiz-app"
        }

        payload = {
            "model": "deepseek/deepseek-r1:free",
            "messages": [
                {"role": "system", "content": "You are a math tutor. Explain mistakes in 2 sentences."},
                {
                    "role": "user",
                    "content": (
                        f"Problem: {problem}\n"
                        f"Wrong Answer: {user_answer}\n"
                        f"Correct Answer: {correct_answer}\n"
                        "Explain the mistake:"
                    )
                }
            ],
            "temperature": 0.3,
            "max_tokens": 2000,  # Reduced slightly to avoid cutoff
            # Optionally add 'stop' if supported by API, like "stop": ["\n\n"]
        }

        try:
            response = requests.post(
                f"{self.base_url}/chat/completions",
                headers=headers,
                json=payload,
                timeout=10
            )
            response.raise_for_status()
            response_json = response.json()

            # Debug print entire response once
            # print("Full API response:", response_json)

            msg = response_json["choices"][0]["message"]

            # Check 'content' first, then 'reasoning', fallback
            explanation = msg.get("content") or msg.get("reasoning") or "⚠️ No explanation provided."
            return explanation.strip()

        except requests.exceptions.RequestException as e:
            return f"⚠️ API Error: {str(e)}"
        except KeyError:
            return "⚠️ Error: Unexpected API response format"

# Usage example
if __name__ == "__main__":
    explainer = AIExplainer()
    example_problem = "A man distributed Rs. 100 equally among his friends. If there had been 5 more friends, each would have received one rupee less. How many friends does he have?"
    wrong_ans = "35"
    correct_ans = "20"
    explanation = explainer.generate_explanation(example_problem, wrong_ans, correct_ans)
    print("Explanation:", explanation)
