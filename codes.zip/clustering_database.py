import pandas as pd
from sentence_transformers import SentenceTransformer
from sklearn.cluster import KMeans
import numpy as np

# File paths (adjust if needed)
train_path = 'C:/Users/X1/Desktop/mini-project/codes/train.csv'
valid_path = 'C:/Users/X1/Desktop/mini-project/codes/validation.csv'
test_path = 'C:/Users/X1/Desktop/mini-project/codes/test.csv'

train_out = 'C:/Users/X1/Desktop/mini-project/codes/train_with_difficulty.csv'
valid_out = 'C:/Users/X1/Desktop/mini-project/codes/valid_with_difficulty.csv'
test_out = 'C:/Users/X1/Desktop/mini-project/codes/test_with_difficulty.csv'

# Load CSVs
train_df = pd.read_csv(train_path)
valid_df = pd.read_csv(valid_path)
test_df = pd.read_csv(test_path)

# Print columns to verify column names
print("Train CSV columns:", train_df.columns.tolist())
print("Valid CSV columns:", valid_df.columns.tolist())
print("Test CSV columns:", test_df.columns.tolist())

# Load sentence transformer model
model = SentenceTransformer('all-MiniLM-L6-v2')

# Function to get embeddings from 'Problem' column
def get_embeddings(df):
    if 'Problem' in df.columns:
        texts = df['Problem'].tolist()
    else:
        raise ValueError("CSV does not contain 'Problem' column")
    return model.encode(texts, show_progress_bar=True)

# Get embeddings for train, valid, test sets
print("Embedding training problems...")
train_embeds = get_embeddings(train_df)

print("Embedding validation problems...")
valid_embeds = get_embeddings(valid_df)

print("Embedding test problems...")
test_embeds = get_embeddings(test_df)

# Cluster training set embeddings with KMeans
num_clusters = 3
kmeans = KMeans(n_clusters=num_clusters, random_state=42)
kmeans.fit(train_embeds)

# Map clusters to difficulty by centroid norms heuristic
centroids = kmeans.cluster_centers_
centroid_norms = np.linalg.norm(centroids, axis=1)
difficulty_order = np.argsort(centroid_norms)  # smallest norm = easiest?

difficulty_map = {
    difficulty_order[0]: 'Easy',
    difficulty_order[1]: 'Medium',
    difficulty_order[2]: 'Hard'
}

# Assign difficulty labels to train set
train_labels = kmeans.labels_
train_df['difficulty'] = [difficulty_map[label] for label in train_labels]

# Predict difficulty on valid and test sets
valid_labels = kmeans.predict(valid_embeds)
valid_df['difficulty'] = [difficulty_map[label] for label in valid_labels]

test_labels = kmeans.predict(test_embeds)
test_df['difficulty'] = [difficulty_map[label] for label in test_labels]

# Save updated CSVs with difficulty labels
train_df.to_csv(train_out, index=False)
valid_df.to_csv(valid_out, index=False)
test_df.to_csv(test_out, index=False)

print("Difficulty labeling complete and saved:")
print(f"- {train_out}")
print(f"- {valid_out}")
print(f"- {test_out}")
